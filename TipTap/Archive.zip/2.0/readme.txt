TipTap 2.0 RC1 - (02/26/2006)
--------------------------

This is a release candidate version. Although it has been tested, you may find bugs. I would appreciate if you could report them to me.
If you want the latest stable release (1.9), you can find it at:

http://geocities.com/leedhas/

Thank you for choosing TipTap.

Nicola Ferralis
feranick@hotmail.com