These are release notes for the OnBoard Suite.  These tools are free software 
under the GNU General Public License.  

The official OnBoard C website is:

	http://onboardc.sourceforge.net/	


              * * * * * * * * * * * * * * * * * * * *

  IMPORTANT NOTE TO EXISTING USERS:  We've made some changes to
  OnBoardHeader.h.  Not only does the default version now support OS4.0
  but we've also removed some data types that are incompatible with the
  PRC tools.  If you've got a pre-existing product you need to either:
  
	1) include "OnBoardCompatability.h" (included in the
	   OnBoardC/Samples directory) and, possibly, "MathLib.h", or
	2) replace OnBoardHeader.h with OnBoardHeader35.h (also in
	   the Samples directory).
  
  Note that if you use the skeleton to make a new program, you'll need the
  new OnBoardHeader.h (it's v40).  Our goal, with this change, was to make
  it easier to port OnBoardC programs to the PRC tools and vice versa.
  Thanks for you understanding.

              * * * * * * * * * * * * * * * * * * * *


You can learn more about using OnBoard C from:

	http://groups.yahoo.com/group/onboardc  

You can learn more about developing OnBoard C (and can always get the latest
realease) from:

	http://sourceforge.net/projects/onboardc

You can learn more about the GNU Public License from:

	http://www.fsf.org/licenses/gpl.html	

-------------------------------------------
Release 2.2.1

The files in this release are:

	onboardc_src_2_2.tar.gz
	onboardc_src_2_2.zip
		o source tree
		o ExampleProjects
		o Documentation
		o OnBoardHeader_h.pdb
		o README
		o COPYING.txt

	onboardc_prc_2_2.tar.gz
	onboardc_prc_2_2.zip
		o OnBoardC.prc, OnBoard.prc, SrcEdit.prc
		o ExampleProjects
		o Documentation
		o OnBoardHeader_h.pdb
		o README
		o COPYING.txt

These files build with the PRC toolkit using Gnu C Compiler version
2.95.3-kgpd.

The changes in this release are:

OnBoard C:
	(C053) Fix BUG: Bitfields stop OnBC compilation (Bug #677184)
	(C045) Add OnBoardHeader40_h.  This includes removing datatypes not
	       supported by PRC tools.
	(C046) Remove math.h functions
	(C047) Replace skeleton with one from Cookbook
	(C044) Multi-Segment Support (actually, it was there before -- we 
	       just verified that)
	(C012) BUG: Including "MathLib.h" produces "Duplicate Global 
	       Definition" error.
	(C055) Install the __OBC__, __FILE__, and __LINE__ macros.


OnBoard Asm:
	(A001) Add EQU Directive
	(A002) Add Systrap Directive

SrcEdit:
	(S044) Asm keyword highlighting
	(S038) SrcEdit Search (beep) if not found (Feature #624277a)
	(S043) SrcEdit long line hang

Sherpa:
	(H009) Give Sherpa its own makefile.
	(H010) Generate human readable assembly from .obj

Documentation:
	(D007) User's Guide: segmentation.
	(D009) Cookbook: Libraries and Preferences.

