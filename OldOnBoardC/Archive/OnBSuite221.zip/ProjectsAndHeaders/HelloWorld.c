/* HelloWorld.c

	- presents a form with an OK
	button and a text field. When
	the text field is blank, the OK
	button causes "Hello World"
	to appear, otherwise the contents
	of the field are reversed.
*/

#define TEXTFIELD 1000

Boolean mainFormEventHandler(EventPtr event)
{
	Boolean handled = false;
	FormPtr frm = FrmGetActiveForm();
	Word fldIndex = FrmGetObjectIndex(frm, TEXTFIELD);
	FieldPtr fld = FrmGetObjectPtr(frm, fldIndex);
	switch (event->eType) {
		case frmOpenEvent : {
			FrmDrawForm(frm);
			Handle h = MemHandleNew(32);
			StrCopy(MemHandleLock(h), "Hello World");
			MemHandleUnlock(h);			
			FldSetText(fld, h, 0, 11);
			handled = true;
		}
		break;
		case ctlSelectEvent : {
			Handle h = FldGetTextHandle(fld);
			FldSetTextHandle(fld, NULL);
			if (h != NULL) {
				CharPtr p = MemHandleLock(h);
				int length = StrLen(p);
				if (length == 0) {
					MemHandleFree(h);
					h = MemHandleNew(12);
					StrCopy(MemHandleLock(h), "Hello World");
					MemHandleUnlock(h);			
					FldSetText(fld, h, 0, 11);
				}
				else {
					int i;
					for (i = 0; i < length/2; i++) {
						char t = p[length - 1 -  i];
						p[length - 1 -  i] = p[i];
						p[i] = t;
					}
					MemHandleUnlock(h);
					FldSetText(fld, h, 0, length);
				}
				FrmDrawForm(frm);
			}		
		}
		break;
	}
	return handled;
}
