/*	EventLoop.c	*/

/*
	Common code for OnBoardC examples.
	
	- Provides main entry point (PilotMain)
	that responds to normalLaunch only.

	- Expects an event handler defined in another
	application file:
	
        Boolean mainFormEventHandler(EventPtr event)

	that gets installed as the handler for
	the initial form.
	
	- Assumes MAINFORM 1000
	
	- Initializes MathLib if possible.
*/

#define MAINFORM 1000
int MathLibRef = -1;
extern Boolean mainFormEventHandler(EventPtr evt);

void initMath()
{
	Err err;
	err = SysLibFind("MathLib", &MathLibRef);
	if (err != 0) { // library not loaded already
		err = SysLibLoad('libr', 'MthL', &MathLibRef);
			if (err == 0)
		    	err = MathLibOpen(MathLibRef, 1);
	}
}

void termMath()
{
	if (MathLibRef != -1) {
		Err err;
		UInt usecount;
		err = MathLibClose(MathLibRef, &usecount);
		if (usecount == 0)
			SysLibRemove(MathLibRef);
	}
}

Boolean appHandleEvent(EventPtr event)
{
	FormPtr	frm;
	Int		formId;
	Boolean	handled = false;
	if (event->eType == frmLoadEvent) {
		formId = event->data.frmLoad.formID;
		frm = FrmInitForm(formId);
		FrmSetActiveForm(frm);
		if (formId == MAINFORM)
			FrmSetEventHandler (frm, mainFormEventHandler);
		handled = true;
	}	
	return handled;
}

DWord PilotMain(Word cmd, char *cmdPBP, Word launchFlags)
{
	EventType event;
	Word error;
	if (cmd == sysAppLaunchCmdNormalLaunch) {
		initMath();
		FrmGotoForm(MAINFORM);
		do {
			EvtGetEvent(&event, 30);
			if (!SysHandleEvent(&event))
				if (!MenuHandleEvent(0, &event, &error))
    					if (!appHandleEvent(&event))
						FrmDispatchEvent(&event);
		} while (event.eType != appStopEvent);
		termMath();
		FrmCloseAllForms();
	}
	return 0;
}
 