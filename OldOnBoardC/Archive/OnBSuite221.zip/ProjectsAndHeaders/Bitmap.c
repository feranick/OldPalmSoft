/* Bitmap.c

	- presents a blank form, a bitmap
	 (resource id BITMAP_ID)
	is displayed in the center
*/

#define BITMAP_ID 1000

Boolean mainFormEventHandler(EventPtr event)
{
	Boolean handled = false;
	FormPtr frm = FrmGetActiveForm();
	switch (event->eType) {
		case frmOpenEvent : {
			FrmDrawForm(frm);
			Handle h = DmGetResource('Tbmp', BITMAP_ID);
			if (h) {
				BitmapPtr bmp = (BitmapPtr)MemHandleLock(h);
				int x = (160 - bmp->width) >> 1;
				int y = (160 - bmp->height) >> 1;
				WinDrawBitmap(bmp, x, y);
				MemHandleUnlock(h);
				DmReleaseResource(h);
			}
			handled = true;
		}
		break;
	}
	return handled;
}
