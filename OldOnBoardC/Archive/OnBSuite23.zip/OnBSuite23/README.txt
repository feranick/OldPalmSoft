These are release notes for the OnBoard Suite.  These tools are free software 
under the GNU General Public License.  The OnBoard Suite homepage (where you 
can always get the latest downloads) can be found at:

	http://onboardc.sourceforge.net/

This page points to the user's forum on Yahoo:

	http://groups.yahoo.com/group/onboardc

and the developer's pages on SourceForge

	http://sourceforge.net/projects/onboardc

You can learn more about the GNU Public License from:

	http://www.fsf.org/licenses/gpl.html	

-------------------------------------------
Release 2.3

The files in this release are:

	onboardc_src_2_1.tar.gz
	onboardc_src_2_1.zip
		o source tree
		o ExampleProjects
		o Documentation
		o OnBoardHeader_h.pdb
		o README
		o COPYING.txt

	onboardc_prc_2_1.tar.gz
	onboardc_prc_2_1.zip
		o OnBoardC.prc, OnBoard.prc, SrcEdit.prc
		o ExampleProjects
		o Documentation
		o OnBoardHeader_h.pdb
		o README
		o COPYING.txt

These files build with the PRC toolkit using Gnu C Compiler version
2.95.3-kgpd.

The changes in this release are:

	OnBoard 
		(A004)  Add jmp instruction  Steve Little 
		(A003)  Add status message when processing includes
		(?)     BUG: old assembly code didn't work
	
	OnBoard C
		(C010)  BUG: OBC Program doesn't hotsync.
		(C058)  Add libr support to OnBC
		(C056)  Set backup bit on skeleton

	SrcEdit
		(S047)  Set backup bit on new source

	Documentation
		(none)

	Sherpa
		(none)

Also, the directory structure was changed.


-------------------------------------------
From Release 2.2

  IMPORTANT NOTE TO EXISTING USERS:  We've made some changes to
  OnBoardHeader.h.  Not only does the default version now support OS4.0
  but we've also removed some data types that are incompatible with the
  PRC tools.  If you've got a pre-existing product you need to either:
  
	1) include "OnBoardCompatability.h" (included in the
	   OnBoardC/Samples directory) and, possibly, "MathLib.h", or
	2) replace OnBoardHeader.h with OnBoardHeader35.h (also in
	   the Samples directory).
  
  Note that if you use the skeleton to make a new program, you'll need the
  new OnBoardHeader.h (it's v40).  Our goal, with this change, was to make
  it easier to port OnBoardC programs to the PRC tools and vice versa.
  Thanks for you understanding.

