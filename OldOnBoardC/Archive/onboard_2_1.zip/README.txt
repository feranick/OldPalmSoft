These are release notes for the OnBoard Suite.  These tools are free software 
under the GNU General Public License.  You can learn more about using 
OnBoard C from:

	http://groups.yahoo.com/group/onboardc  

You can learn more about developing OnBoard C (and can always get the latest
realease) from:

	http://sourceforge.net/projects/onboardc

You can learn more about the GNU Public License from:

	http://www.fsf.org/licenses/gpl.html	

-------------------------------------------
Release 2.1 

The files in this release are:

	onboardc_src_2_1.tar.gz
	onboardc_src_2_1.zip
		o source tree
		o ExampleProjects
		o Documentation
		o OnBoardHeader_h.pdb
		o README
		o COPYING.txt

	onboardc_prc_2_1.tar.gz
	onboardc_prc_2_1.zip
		o OnBoardC.prc, OnBoard.prc, SrcEdit.prc
		o ExampleProjects
		o Documentation
		o OnBoardHeader_h.pdb
		o README
		o COPYING.txt

These files build with the PRC toolkit using Gnu C Compiler version
2.95.3-kgpd.

The changes in this release are:

	OnBoard / OnBoard C
		o (C029) Get the source compiling Falch.net toolkit
		o (C001) Get the source compiling in latest version of 
		         CodeWarrior with SDK 4.0
		o (C033) Get the source compiling with -mdebug-labels in GCC
		o (C031) BUG: OnBoard goto crash. HandEra330. (Bug 616965)
		o (C035) QED Support 
		o (C036) Makefiles with debug target

	SrcEdit
		o (S019) When you are not on Color/Grayscale mode, there are 
		         bugs with the UI graphics
		o (S031) BUG: Paste to doc start causes reset
		o (S004) Finish Save-As feature. 
		o (S035) BUG: Clipboard errors. (Bug #620985)
		o (S015) Add optional color highlighting support for keywords
		o (S014) Add color highlighting support for /* */ comment style.
		o (S021) Tiny font support for non-English character sets
		o (S026) Makefiles with debug target
		o Added font tiny support for non-US people (like me). 
		o Fixed a bug which caused the cursor not to hide itself  
		o Made the current file highlighted on the Open Dialog box. 
		o Fixed a bug concerning this last one with OS 3.3 
		o Improved the system of finding a file by typing its first 
		  letter. 
		o Bug with a field that was stuck to the screen corrected. 
		o When you do a find, the screen was not horizontally scrolled 
		  to make you see what you were searching for.
		o Corrected the shortcut bug (now I use 'shortcut u 1' to 
		  write UInt8 :) I even write 'shortcut f' to write FrmAlert(); 
		o Fixed a memory management bug that would make SrcEdit crash 
		  if we try to open an invalid DOC (for instance with no 
		  record #0) 
		o Secured the loading of DOC files 
		o Made SrcEdit copy its own clipboard to the system clipboard 
		  when launching a Search (to be able to paste what you 
		  copied in the search field) 
		o Optimized the horizontal scrolling (blitting with X multiple 
		  of 10 is significantly faster for some reason so I used this) 
		o Optimized the speed for finding the list of the files when 
		  loading the Open Dialog

	Documentation
		o (C037) Modify documentation (Replaced documentation with 
		         Users' Guide and Cookbook).

	Sherpa
		o Added the Sherpa porting tool to port source from PalmOS to 
		  the Host/PRC Tools.
