EuroConv for PalmOS
---------------------

Requirements

1) PalmOS powered PDA. This program has been tested on PalmOS 3.5, 4.1, 5, 5.2



Warning:
WE ARE NOT RESPONSIBLE FOR ANY DATA LOSS. 


Legal statement:

This program is freeware. It can be distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. It can not be altered or modified in any way without the permission of the author. USE AT YOUR OWN RISK. Separate distribution of the following 2 files:

EuroConv.prc
README_EuroConv.txt (this file)

is not permitted. However the distribution of the the overall package is warmly encouraged.




For comments, suggestions, bugs, please email me:

Nicola Ferralis
feranick@hotmail.com

 
(version included in this distribution: 0.3 built 120703)
