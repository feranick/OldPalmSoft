PalmTVA 1.5 beta (2006/24/02)
-----------------------------

This is a beta version. Although it has been tested, you may find bugs. I would appreciate if you could report them to me.

If you want the latest stable release (1.2), you can find it at:

http://geocities.com/leedhas/

Thank you for choosing PalmTVA.

Nicola Ferralis
feranick@hotmail.com