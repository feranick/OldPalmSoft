PhysConst for PalmOS
---------------------

Requirements

PalmOS powered PDA. This program has been tested on PalmOS 3.5, 4.1, 5, 5.2




Legal statement

This program is freeware. The Constants are collected from NIST database. The author is not affiliated to NIST in any meaning. NIST cannot be held responsible for any mistakes included in the program. PhysConst can be distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY on the performance of the program; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. It can not be altered or modified in any way without the permission of the author. Separate distribution of the following 2 files:

PhysConst.prc
README_PhysConst.txt (this file)

is not permitted. However the distribution of the the overall package is warmly encouraged.




For comments, suggestions, bugs, please email me:

Nicola Ferralis
feranick@hotmail.com

 
(version included in this distribution: 1.1.3 built 092203)
