#define AppCreator 'nick'
#define MainForm		1000
#define AboutForm 1100
#define SIForm 1200
	#define CopyMenu 1900
	#define OptionsMenuAbout 2000
	#define ConstMenu 1250
	#define SIMenu 1050
	#define QuantityField 2100
	#define NameSIField 2200
	#define SymbolSIField 2300
	#define SymbolDerField 2400
	#define ConstantField 3000
	#define ConstantField2 3001
	#define UnitsField 3010
	#define ConstValueField 3100
	#define ConstantList 3005
	#define ConstantPopup 3006
	#define UnitsList 3015
	#define UnitsPopup 3016
	#define SIPopup 2006
	#define DerPopup 2016
	#define SIList 2005
	#define DerList 2015
	#define CopyBtn 2500
	#define SymbolDerInfo 2600 
	#define CloseAboutMenuBtn 1110
	#define SIBtn 1251
	#define ConstBtn 1051
	#define listCountM 37
	#define LCount2 2
	#define LCount3 3
	#define LCount4 4 
	#define LCount6 6
	#define LCount7 7
	#define LCount17 17
	#define LCountC 56
	#define LCount46 46


	// *** PUT UI-DEFINITIONS HERE *** //
	
	// Prototypes
	int d,g;
	static char StringCopy[80];
		static Boolean	appHandleEvent (EventPtr event);
	static void	mainFormInit (FormPtr form);
	static void	AboutFormInit (FormPtr form);
	static void	SIFormInit (FormPtr form);
	static Boolean	mainFormEventHandler (EventPtr event);
	static Boolean	AboutFormEventHandler (EventPtr event);
	static Boolean	SIFormEventHandler (EventPtr event);
	static Boolean	doMenu(FormPtr frmP, Word command);
	static Boolean	doMenuSI(FormPtr frmP, Word command);
	void	*getObjectPtr (FormPtr frmP, Int resourceNo);
	static void getFieldText (UInt32 fIndex, char *StrToGet);
	static void setFieldText (UInt32 fIndex, char *StrToShow);
	static void	nullField (UInt32 fIndex);
	

	//list handling prototypes
	void LstDrawList (ListType *listP) SYS_TRAP(sysTrapLstDrawList);
	void LstSetDrawFunction (ListType *listP, ListDrawDataFuncPtr func) 
		SYS_TRAP(sysTrapLstSetDrawFunction);
	void WinDrawTruncChars (Char *c, int i, int x, int y, int w)
		SYS_TRAP(sysTrapWinDrawTruncChars);
	
	static char	*Blanklist[1]= {" "};
	static char blank[30] ="   ";
	static char	*listStringM[listCountM]= {"Astronomical Constants","Atomic Mass","Atomic Unit", "Avogadro Constant","Bohr Magneton", 
								"Bohr Radius","Boltzmann Constant","Charact. Impedance of vacuum",
								"Electric Constant", "Electron Charge to Mass ratio",
								"Electron g factor","Electron gyromagnetic ratio", "Electron gyromag. ratio/2Pi",
								  "Electron Magnetic Moment","Electron Mass","Electron Volt","Elementary Charge","Exposure (Langmuir)",
								"Faraday Constant","Fine Structure Constant","Inverse Fine Structure Const.","Hartree Energy", 
								"Joule Conversion","Kelvin Conversion","Kilogram Conversion","Silicon Lattice Constant",
								"Magnetic Constant","Magnetic Flux Quantum","Newton Gravit. Constant", 
								"Newton Gravit. Const/(hbar*c)", "Plank Constant", "Plank Constant/2Pi   (hbar)",
								"Rydberg Constant", "Speed of light in vacuum", "Standard gravity acceleration",
								"Standard atmosphere", "Stefan-Boltzman Constant"};
	static char	*listAstroUnits[LCountC]= {"Astronomical Unit AU", "cosmic background temperature","light year","Parsec","Hubble expansion rate", 
								"Mass Sun","Radius Sun","g Sun", "Luminosity Sun", "Solar Temperature",  
								"Mass Mercury","Radius Mercury","g Mercury","Period Mercury", "ecc. Mercury",
								"Mass Venus","Radius Venus","g Venus","Period Venus", "ecc. Venus", 
								"Mass Earth","Radius Earth","g Earth","Period Earth", "ecc. Earth",
								"Mass Mars","Radius Mars","g Mars","Period Mars", "ecc. Mars",
								"Mass Jupiter","Radius Jupiter","g Jupiter","Period Jupiter", "ecc. Jupiter",   
								"Mass Saturn","Radius Saturn","g Saturn","Period Saturn", "ecc. Saturn",
								"Mass Uranus","Radius Uranus","g Uranus","Period Uranus", "ecc. Uranus",
								"Mass Pluto","Radius Pluto","g Pluto","Period Pluto", "ecc. Pluto",						
								"Mass Moon","Radius Moon","g Moon","Period Moon", "ecc. Moon","Earth-Moon dist."};						
								   	
static char *listAstroValues1[LCountC]= {"1.496e11","2.728","9.463e15","3.0856775807e16","60 - 80","1.991e30", "6.96e8","274", "3.9e26","5780",
							"3.303e23","2.439e6","3.61","0.24085", "0.205622",  
							"4.870e24","6.050e6","8.83","0.61521","0.006783",
							"5.976e24","6.378e6","9.806","1.00004", "0.016684",
							"6.418e23","3.397e6","3.61","1.523705","0.093404",
							"1.899e27","7.140e7","25.9","11.8622","0.047826",
							"5.686e26","6.000e7","11.2","29.4577","0.052754",
							"8.66e25","2.615e7","9.04","84.0139","0.050363",
							"1.030e26","2.43e7","13.3","164.793","0.004014",
							"7.349e22","1.738e6","1.62","0.07481","0.05490","3.8e8"};
static char	*listAstroUnits2[LCountC]= {"m", "K","m","m","km/s", "kg","m","m/s�","J/s","K","kg","m","m/s�","yr"," ",   	
							"kg","m","m/s�","yr"," ",
"kg","m","m/s�","yr"," ",  "kg","m","m/s�","yr"," ",  "kg","m","m/s�","yr"," ",    
"kg","m","m/s�","yr"," ",    "kg","m","m/s�","yr"," ",    "kg","m","m/s�","yr"," ",    "kg","m","m/s�","yr"," ","m"};
	static char	*listPlanckUnits[LCount2]= {"J*s", "eV*s"};
	static char	*listPlanckUnits2[LCount2]= {"J*s", "eV*s"};
	static char *listPlanckValues1[LCount2]= {"6.62606876e-34", "4.13566727e-15"};
	static char *listPlanckValues2[LCount2]= {"1.054571596e-34", "6.58211889e-16"};
	static char	*listBoltzmannUnits[LCount4]= {"J/K", "eV/K", "Hz/K", "1/(m*K)"};
	static char	*listBoltzmannUnits2[LCount4]= {"J/K", "eV/K", "Hz/K  (kB/h)", "1/(m*K)  (kB/hc)"};
	static char *listBoltzmannValues1[LCount4]= {"1.3806503e-23", "8.617342e-5", "2.0836644e+10", "6.950356e+4"};
	static char	*listAtomicMassUnits[LCount6]= {"kg", "J", "eV", "Eh", 
								"Hz", "K"};
	static char	*listAtomicMassUnits2[LCount6]= {"u-kg (1u)", "u-J  (1u)c�", "u-eV  (1u)c�", "u-Eh  (1u)c�", 
								"u-Hz  (1u)c�/h", "u-K  (1u)c�/kB"};

	static char *listAtomicMassValues1[LCount6]= {"1.6605e-27", "1.4924e-10", "9.31494e+8", "3.4231777e+7",
								"2.2523e+23", "1.08096e+13"};
	
	static char	*listAtomicUnits[LCount17]= {"C", "C*m�", "A", "C m", 
							"C m�", "V /m", "J", "eV", "N", "m", "J*T^-1", "T", "kg", "kg*m/s", "F*m^-1", "s", "m*s^-1"};
	static char	*listAtomicUnits2[LCount17]= {"Charge e", "Charge density e/a0^3", "Current e*Eh/hbar", "Electric Dipole Moment e*a0",
								"Electric Quad. Moment e*a0�", "Electric Field Eh/e*a0", "Energy (Rydberg) Eh","Energy (Rydberg) Eh",
								 "Force Eh/a0", "Bohr Radius a0", "Magnetic Dipole Moment hbar*e/me", "Mag. Flux Density hbar/e*a0�", 
								"Mass me","Momentum hbar/a0", "Permittivity e�/a0*Eh", "Time hbar/Eh", "Velocity a0*Eh"} ;
	
	static char *listAtomicValues1[LCount17]= {"1.602176462e-19", "1.081202285e12", "6.62361753e-3", "8.47835267e-30",
								"4.48655100e-40", "5.14220624e11", "4.35974381e-18", "27.2113834", "8.23872181e-8",
								"0.5291772083e-10","1.854801799e-23", "2.350517349e5", "9.10938188e-31", "1.99285151e-24", "1.112650056e-10",
								"2.4188843265e-17", "2.1876912529e6"};
	
	static char	*listBohrMagUnits[LCount4]= {"eV/T", "Hz/T","1/(m*T)", "K/T"};
	static char	*listBohrMagUnits2[LCount4]={"�B", "�B/h", "�B/(h*c)", "�B/kB"};
	static char *listBohrMagValues1[LCount4]={"5.788381749e-5", "13.99624624e9","46.6864521", "0.6717131"};
	static char	*listElMagMomUnits[LCount3]= {"J/T", " "," "};
	static char	*listElMagMomUnits2[LCount3]={"�e", "to Bohr mag. ratio (�e/�B)", "to nuclear mag. ratio (�B/�N)"};
	static char *listElMagMomValues1[LCount3]={"-928.476 362e-26", "-1.0011596521869","-1838.2819660"};
	static char	*listElMassUnits[LCount4]= {"kg", "J"," MeV", "u"};
	static char	*listElMassUnits2[LCount4]={"me", "J energy equiv. (me*c�)", "MeV energy equiv. (me*c�)", "me in u unit"};
	static char *listElMassValues1[LCount4]={"9.10938188e-31", "8.18710414e-14","0.510998902", "5.485799110e-4"};

	static char	*listElVoltUnits[LCount7]= {"J", "u"," Eh", "Hz", "1/m", "K", "kg"};
	static char	*listElVoltUnits2[LCount7]={"eV", "eV-u  (1eV)/c�", "eV-Eh", "eV-Hz  (1eV)/h", "eV-m^-1  (1eV)/(h*c)",
								"eV-K  (1eV)/kB", "eV-kg  (1eV)/c�"};
	static char *listElVoltValues1[LCount7]={"1.602176462e-19", "1.073544206e-9","3.67493260e-2", "2.417989491e14",
								"8.06554477e5", "1.1604506e4", "1.782661731e-36"};

	static char	*listHartreeUnits[LCount7]= {"J", "eV","u", "Hz", "1/m", "K", "kg"};
	static char	*listHartreeUnits2[LCount7]={"Eh", "Eh  (eV)", "Eh-u  (Eh/c�)","Eh-Hz  (Eh/h)","Eh-m^-1  (Eh/(h*c))",
								"Eh-K  (Eh/kB)",  "Eh-kg  (Eh/c�)"};
	static char *listHartreeValues1[LCount7]={"4.35974381e-18", "27.2113834", "2.921262304e-8", "6.579683920735e15",
								"2.194746313710e7","3.1577465e5", "4.85086919e-35"};
	static char	*listJouleUnits[LCount7]= {"eV","Eh","u","Hz", "1/m", "K", "kg"};
	static char	*listJouleUnits2[LCount7]={"J-eV", "J-Eh" ,"J-u  (1J/c�}","J-Hz  (1J/h)", "J-m^-1  (1J/(h*c))",
								"J-K  (1J/kB)","J-Kg  (1J/C�)" };
	static char *listJouleValues1[LCount7]={"6.24150974e18","2.29371276e17","6.70053662e9", "1.509190e33",
								"5.03411762e24", "7.242964e22","1.112650056e-17"};
	static char	*listKelvinUnits[LCount7]= {"J", "eV", "Eh","Hz","1/m","u","kg"};
	static char	*listKelvinUnits2[LCount7]={"K-J  (1K)*kB","K-eV  (1K)*kB","K-Eh  (1K)*kB","K-Hz  (1K)*kB/h",
								"K-m^-1  (1K*kB/(h*c))","K-u  (1K*kB/c�)","K-kg  (1K*kB/c�)"};
	static char *listKelvinValues1[LCount7]={"1.3806503e-23","8.617342e-5","3.1668153e-6","2.0836644e10",
								"69.50356", "9.251098e-14","1.5361807e-40" };
	static char	*listkgUnits[LCount7]= {"u","eV","Eh","Hz","1/m","J","K"};
	static char	*listkgUnits2[LCount7]={"kg-u","kg-eV  (1kg*c�)","kg-Eh  (1kg*c�)","kg-Hz  (1kg*c�/h)",
							"kg-m^-1  (1kg*c/h)","kg-J  (1kg*c�)","kg-K  (1kg*c�)/kB"};
	static char *listkgValues1[LCount7]={"6.02214199e26","5.60958921e35","2.06148622e34","1.35639277e50",
							"4.52443929e41","8.987551787e16","6.509651e39"};
	static char	*listRydbergUnits[LCount4]= {"1/m","Hz","eV","J"};
	static char	*listRydbergUnits2[LCount4]={"R inf", "R inf * c","R inf * c*h","R inf * c*h"};
	static char *listRydbergValues1[LCount4]={"1.0973731568549e7", "3.289841960368e15", "13.60569172","2.17987190e-18"};
	static char	*listSIQuantity[LCount7]= {"Amount of substance","Electric Current","Length","Luminous Intensity",
							"Mass","Thermodyn. temperature","Time"};
	static char	*listSIName[LCount7]={"mole","ampere","meter", "candela","kilogram","kelvin","second"};
	static char *listSISymbol[LCount7]={"mol","A","m","cd","kg","K","s"};

	static char	*listDerQuantity[LCount46]= {"Activity (of a radionuclide)","Adsorbed dose rate","Adsorbed dose, specific energy",
								"Angular acceleration","Angular velocity","Capacitance","Catalytic activity","Catalytic concentration",
								"Celsius temperature","Current density", "Dose equivalent","Dynamic viscosity",
								"Electric charge","Electric charge density", "Electric conductance","Electric Field Strength",
								"Electric flux density","Electric Potential", "Electric resistance","Energy","Energy density",
								"Exposure (x-ray)","Force","Frequency","Heat Capacity, entropy","Heat Flux density, irradiance",
								"Illuminance","Inductance","Luminance","Luminous flux","Magnetic Field strength","Magnetic flux",
								"Magnetic flux density","Molar Energy","Molar Entropy","Moment of force","Permeability","Permittivity",
								"Pressure, stress", "Power","Radiance","Radiant intensity","Specific energy","Surface tension",
								"Thermal conductivity", "Wave number"};

	static char	*listDerName[LCount46]={"becquerel","gray per second","gray","radian per sec�","radian per second","farad","katal",
							"katal/meter�","degree Celsius","ampere per meter�","sievert","pascal second","coulomb",
							"coulomb per meter�","siemens","volt per meter","coulomb per meter�","volt","ohm","joule",
							"joule per meter�","coulomb per kg","newton","hertz","joule per kelvin","watt per meter�","lux",
							"henry","candela per meter�","lumen","ampere per meter","weber","tesla","joule per mole",
							"joule per mole kelvin", "newton meter","henry per meter","farad per meter","pascal","watt",
							"watt per meter� steradian","watt per steradian","joule per kg","newton per meter","watt per meter kelvin",
							"reciprocal meter"};

	static char *listDerSymbol[LCount46]={"Bq","Gy/s","Gy","rad/s�","rad/s","F","kat",
							"kat/m�","C","","Sv","Pa*s","C","C/m�","S","V/m","C/m�","V","Omega","J","J/m�","C/kg","N","Hz","J/K",
							"W/m�","lx","H","","lm","A/m","Wb","T", "J/mol","J/(mol*K)","N*m","H/m","F/m","Pa","W","W/(sr*m�)","W/sr",
							"J/kg","N/m","W/(m*K)",""};

	static char *listDerUnits[LCount46]={"1/s","m�/s^3","J/kg  (m�/s�)","1/s�","1/s","C/V  (A*s�)�/(kg*m�)","mol/s",
							"mol/(s*m^-3)","K","A/m�","J/kg  (m�/s�)","kg/(m*s)","A*s","s*A/m�","A/V  (A�*s�/(kg*m�))","m*K*s�/A",
							"s*A/m�","V/A  (kg*s�/(A�*s�))","W/A  (kg*m�/(A*s�))","N*m  (kg*m�/s�)","kg/(m*s�)","s*A/kg",
							"kg*m/s�","1/s","m�/(K*s�)","(kg*m�)/(K*s�)","lm/m�  (cd/m�)","Wb/A  kg*m�/(s�*A�)","cd/m�",
							"cd*sr  (cd*m�/m�=cd)","A/m","V*s  (kg*s�/(A*s�)","Wb/m�  (kg/(A*s))", "kg*m�/(mol*s�)",
							"kg*m�/(mol*K*s�)","kg*m�*s�","m*kg/(A*s�)","(s�)�*4*A�/(kg*m�)","N/m�  (kg/(m*s�))","J/s  (kg*m�/s�)", 
							"kg/s^3","kg*m�/s^3","m�/s�","kg/s�","m*kg/(K*s�)","1/m"};

	static char *listDerInfo[LCount46]={"","","","","","","","","","","","","","","","","","","","1meV=11.6K 1KJ=10.4meV 1kcal=43.4meV 1THz=4.13meV",
							"","","","","","","","","","","","","","","","","","","","","","","","","",""};

void	drawBlanklist	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (Blanklist[i], StrLen(Blanklist[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupBlanklist(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, 1);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawBlanklist);

		// Don't redraw the list
	}


void	drawListM	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listStringM[i], StrLen(listStringM[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListM(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, listCountM);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListM);

		// Don't redraw the list
	}

void	drawlistPlanckUnits	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listPlanckUnits[i], StrLen(listPlanckUnits[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListPlanckUnits(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount2);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawlistPlanckUnits);

		// Don't redraw the list
	}
void	drawlistPlanckUnits2	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listPlanckUnits2[i], StrLen(listPlanckUnits2[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListPlanckUnits2(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount2);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawlistPlanckUnits2);

		// Don't redraw the list
	}

void	drawListPlanckValues1	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listPlanckValues1[i], StrLen(listPlanckValues1[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListPlanckValues1 (int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount2);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListPlanckValues1);

		// Don't redraw the list
	}
//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

void	drawlistAstroUnits	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listAstroUnits[i], StrLen(listAstroUnits[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListAstroUnits(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCountC);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawlistAstroUnits);

		// Don't redraw the list
	}
void	drawlistAstroUnits2	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listAstroUnits2[i], StrLen(listAstroUnits2[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListAstroUnits2(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCountC);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawlistAstroUnits2);

		// Don't redraw the list
	}

void	drawListAstroValues1	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listAstroValues1[i], StrLen(listAstroValues1[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListAstroValues1 (int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCountC);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListAstroValues1);

		// Don't redraw the list
	}


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

void	drawListBoltzmannUnits	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listBoltzmannUnits[i], StrLen(listBoltzmannUnits[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListBoltzmannUnits(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount4);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListBoltzmannUnits);

		// Don't redraw the list
	}
void	drawListBoltzmannUnits2	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listBoltzmannUnits2[i], StrLen(listBoltzmannUnits2[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListBoltzmannUnits2(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount4);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListBoltzmannUnits2);

		// Don't redraw the list
	}




void	drawListAtomicMassUnits	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listAtomicMassUnits[i], StrLen(listAtomicMassUnits[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListAtomicMassUnits(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount6);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListAtomicMassUnits);

		// Don't redraw the list
	}
void	drawListAtomicMassUnits2	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listAtomicMassUnits2[i], StrLen(listAtomicMassUnits2[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListAtomicMassUnits2(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount6);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListAtomicMassUnits2);

		// Don't redraw the list
	}



void	drawListAtomicUnits	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listAtomicUnits[i], StrLen(listAtomicUnits[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListAtomicUnits(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount17);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListAtomicUnits);

		// Don't redraw the list
	}
void	drawListAtomicUnits2	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listAtomicUnits2[i], StrLen(listAtomicUnits2[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListAtomicUnits2(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount17);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListAtomicUnits2);

		// Don't redraw the list
	}



void	drawListBohrMagUnits	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listBohrMagUnits[i], StrLen(listBohrMagUnits[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListBohrMagUnits(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount4);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListBohrMagUnits);

		// Don't redraw the list
	}
void	drawListBohrMagUnits2	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listBohrMagUnits2[i], StrLen(listBohrMagUnits2[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListBohrMagUnits2(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount4);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListBohrMagUnits2);

		// Don't redraw the list
	}



void	drawListElMagMomUnits	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listElMagMomUnits[i], StrLen(listElMagMomUnits[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListElMagMomUnits(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount3);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListElMagMomUnits);

		// Don't redraw the list
	}
void	drawListElMagMomUnits2	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listElMagMomUnits2[i], StrLen(listElMagMomUnits2[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListElMagMomUnits2(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount3);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListElMagMomUnits2);

		// Don't redraw the list
	}




void	drawListElMassUnits	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listElMassUnits[i], StrLen(listElMassUnits[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListElMassUnits(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount4);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListElMassUnits);

		// Don't redraw the list
	}
void	drawListElMassUnits2	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listElMassUnits2[i], StrLen(listElMassUnits2[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListElMassUnits2(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount4);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListElMassUnits2);

		// Don't redraw the list
	}



void	drawListHartreeUnits	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listHartreeUnits[i], StrLen(listHartreeUnits[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListHartreeUnits(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount7);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListHartreeUnits);

		// Don't redraw the list
	}
void	drawListHartreeUnits2	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listHartreeUnits2[i], StrLen(listHartreeUnits2[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListHartreeUnits2(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount7);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListHartreeUnits2);

		// Don't redraw the list
	}



void	drawListElVoltUnits	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listElVoltUnits[i], StrLen(listElVoltUnits[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListElVoltUnits(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount7);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListElVoltUnits);

		// Don't redraw the list
	}
void	drawListElVoltUnits2	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listElVoltUnits2[i], StrLen(listElVoltUnits2[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListElVoltUnits2(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount7);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListElVoltUnits2);

		// Don't redraw the list
	}



void	drawListJouleUnits	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listJouleUnits[i], StrLen(listJouleUnits[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListJouleUnits(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount7);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListJouleUnits);

		// Don't redraw the list
	}
void	drawListJouleUnits2	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listJouleUnits2[i], StrLen(listJouleUnits2[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListJouleUnits2(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount7);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListJouleUnits2);

		// Don't redraw the list
	}


void	drawListKelvinUnits	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listKelvinUnits[i], StrLen(listKelvinUnits[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListKelvinUnits(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount7);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListKelvinUnits);

		// Don't redraw the list
	}
void	drawListKelvinUnits2	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listKelvinUnits2[i], StrLen(listKelvinUnits2[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListKelvinUnits2(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount7);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListKelvinUnits2);

		// Don't redraw the list
	}


void	drawListkgUnits	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listkgUnits[i], StrLen(listkgUnits[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListkgUnits(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount7);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListkgUnits);

		// Don't redraw the list
	}
void	drawListkgUnits2	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listkgUnits2[i], StrLen(listkgUnits2[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListkgUnits2(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount7);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListkgUnits2);

		// Don't redraw the list
	}


void	drawListRydbergUnits	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listRydbergUnits[i], StrLen(listRydbergUnits[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListRydbergUnits(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount4);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListRydbergUnits);

		// Don't redraw the list
	}
void	drawListRydbergUnits2	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listRydbergUnits2[i], StrLen(listRydbergUnits2[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListRydbergUnits2(int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount4);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListRydbergUnits2);

		// Don't redraw the list
	}



void	drawListSIQuantity	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listSIQuantity[i], StrLen(listSIQuantity[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListSIQuantity (int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount7);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListSIQuantity);

		// Don't redraw the list
	}

void	drawListDerQuantity	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listDerQuantity[i], StrLen(listDerQuantity[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListDerQuantity (int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount46);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListDerQuantity);

		// Don't redraw the list
	}

void	drawListDerInfo	(Int16 i, RectangleType	*bounds, Char **items)
	{
WinDrawTruncChars (listDerInfo[i], StrLen(listDerInfo[i]), bounds->topLeft.x, bounds->topLeft.y, bounds->extent.x);
	}

	void	setupListDerInfo (int lIndex)
	{
		FormPtr pForm	= FrmGetActiveForm();
		void	*pList	= getObjectPtr(pForm, lIndex);
		LstSetListChoices (pList, 0, LCount46);
		LstSetDrawFunction (pList, (ListDrawDataFuncPtr) drawListDerInfo);

		// Don't redraw the list
	}


///////////////////////////////////////////////////////////////////////////////

	/*
	 * startApp and stopApp are here for future reference.  They clearly 
	 * don't do anything for this program, but it's a good idea to do 
	 * program clean-up and shutdown in these files.  One thing that 
	 * typically goes here is database opening and closing.
	 */

	static void	startApp()	{return;}
	static void	stopApp()	{return;}

	/*
	 * A Palm program starts at the PilotMain function -- you can use 
	 * this example verbatim for most (maybe all) your Palm applications.  
	 * Some other examples might separate the event loop into a separate 
	 * function but we've combined the two, here.  This function does 
	 * the following.
	 *
	 *	o  calls startApp, 
	 *	o  initiates the first form, 
	 *	o  handles the event loop, 
	 *	o  cleans-up (when it gets the 'leaving now' event), and 
	 *	o  leaves.
	 */


		DWord
	PilotMain(Word cmd, char *cmdPBP, Word launchFlags)
	{
		EventType	event;
		Word		error;
		if (cmd == sysAppLaunchCmdNormalLaunch) 
		{
			startApp();

			/*
			 * FrmGotForm generates a frmLoadEvent that'll get 
			 * handled as soon as we have an event handler that 
			 * knows what to do with it.
			 */

			FrmGotoForm(MainForm);

			/*
			 * This loop gets events, handles the events, and 
			 * checks to see if we've got a 'done' event.
			 */

			do 
			{
				/*
				 * Wait for an event (we already generated the 
				 * first one).
				 */

				EvtGetEvent(&event, evtWaitForever);

				/*
				 * Then, ask the system, the menu system, 
				 * and our *OWN* event handlers (one for the 
				 * application as a whole and one for the 
				 * current form) to deal with the event.
				 */

				if (!SysHandleEvent (&event))
				if (!MenuHandleEvent (0, &event, &error))
				if (!appHandleEvent (&event))
					FrmDispatchEvent (&event);

			} while (event.eType != appStopEvent);

			/*
			 * When we're done, shut down
			 */

			stopApp();
			FrmCloseAllForms();
		}
		return 0;
	}

	/*
	 * This is the top-level event handler for the entire application.  
	 * Here, we handle form load events and our menu events.
	 */


		static Boolean 
	appHandleEvent (EventPtr event) 
	{
		FormPtr	frm;
		Int	formId;
		Boolean	handled = false;
		
		if (event->eType == frmLoadEvent) 
		{
			/*
			* Load the resource for the form
			*/

			formId	= event->data.frmLoad.formID;
			frm	= FrmInitForm(formId);

			FrmSetActiveForm(frm);

			/*
			* install a form-specific event handler
			*/

			if (formId == MainForm)
				FrmSetEventHandler (frm, mainFormEventHandler);
			if (formId == AboutForm)
				FrmSetEventHandler (frm, AboutFormEventHandler);
			if (formId == SIForm)
				FrmSetEventHandler (frm, SIFormEventHandler);

			// *** ADD NEW FORM HANDLING HERE *** //
			


			handled = true;
		}       
		return handled;
	}


	/*
	 * This is the event handler for the main form.  It handles all of 
	 * the user interactions with the user interface objects (e.g., 
	 * buttons, lists, text fields, and such) on the main form.
	 */


		static Boolean
	mainFormEventHandler(EventPtr event)
	{
		Boolean	handled	= false;
		FormPtr	frmP	= FrmGetActiveForm();
		switch (event->eType) 
		{

		/*
		 * the first event received by a form's event handler is
		 * the frmOpenEvent.  
		 */

		case frmOpenEvent:
			FrmDrawForm(frmP);
			mainFormInit(frmP);
			handled = true;
			break;  
		case menuEvent:
			handled=doMenu(frmP, event->data.menu.itemID);
			break;

		
		// *** ADD EVENT HANDLING HERE *** //
//BUTTONS
		case ctlSelectEvent:
			switch(event->data.ctlSelect.controlID)
			{
			case	CopyBtn:
			{
				//Copy to Clipboard
				getFieldText(ConstValueField, StringCopy);
				ClipboardAddItem (clipboardText, StringCopy,StrLen(StringCopy));

				handled = true;
				break;
			}
			//other buttons...
			case	SIBtn:
			{	FrmGotoForm(SIForm);
				handled = true;
				break;
			}

			}
			break;

//LISTS

		case popSelectEvent:
	{
		int	i	= event->data.popSelect.selection;

		switch (event->data.popSelect.controlID)
		{
		case ConstantPopup:
						
			setFieldText(ConstantField, listStringM[i]);
			setFieldText(ConstValueField, " ");
			setFieldText(UnitsField, " ");
			setFieldText(ConstantField2, " ");

			if(i==0)
			{setupListAstroUnits(UnitsList);
			d=0;}

			if(i==1)
			{setupListAtomicMassUnits(UnitsList);
			d=1;}
			if(i==2)
			{setupListAtomicUnits2(UnitsList);
			d=2;}
			if(i==3)
			{setupBlanklist(UnitsList);
			setFieldText(UnitsField, "mol^-1");
			setFieldText(ConstantField2, "N");
			setFieldText(ConstValueField, "6.02214199e23");
			d=3;}
			if(i==4)
			{setupListBohrMagUnits(UnitsList);
			d=4;}
			if(i==5)
			{setupBlanklist(UnitsList);
			setFieldText(UnitsField, "m");
			setFieldText(ConstantField2, "a0");
			setFieldText(ConstValueField, "0.5291772083e-10");
			d=5;}
			if(i==6)
			{setupListBoltzmannUnits(UnitsList);
			d=6;}
			if(i==7)
			{setupBlanklist(UnitsList);
			setFieldText(UnitsField, "Ohm");
			setFieldText(ConstantField2, "Z0=Sqrt(�0/epsilon0)/2Pi");
			setFieldText(ConstValueField, "376.730313461");
			d=7;}
			if(i==8)
			{setupBlanklist(UnitsList);
			setFieldText(UnitsField, "F/m");
			setFieldText(ConstantField2, "epsilon0");
			setFieldText(ConstValueField, "8.854187817e-12");
			d=8;}
			if(i==9)
			{setupBlanklist(UnitsList);
			setFieldText(UnitsField, "C/kg");
			setFieldText(ConstantField2, "-e/me");
			setFieldText(ConstValueField, "-1.758820174e11");
			d=9;}
			if(i==10)
			{setupBlanklist(UnitsList);
			setFieldText(UnitsField, "");
			setFieldText(ConstantField2, "ge");
			setFieldText(ConstValueField, "-2.0023193043737");
			d=10;}
			if(i==11)
			{setupBlanklist(UnitsList);
			setFieldText(UnitsField, "1/(s*T)");
			setFieldText(ConstantField2, "gammae");
			setFieldText(ConstValueField, "1.760859794e11");
			d=11;}
			if(i==12)
			{setupBlanklist(UnitsList);
			setFieldText(UnitsField, "MHz/T");
			setFieldText(ConstantField2, "gammae/2Pi");
			setFieldText(ConstValueField, "28024.9450");
			d=12;}
			if(i==13)
			{setupListElMagMomUnits2(UnitsList);
			d=14;}
			if(i==14)
			{setupListElMassUnits2(UnitsList);
			d=14;}
			if(i==15)
			{setupListElVoltUnits2(UnitsList);
			d=15;}
			if(i==16)
			{setupBlanklist(UnitsList);
			setFieldText(UnitsField, "C");
			setFieldText(ConstantField2, "e");
			setFieldText(ConstValueField, "1.602176462e-19");
			d=16;}
			if(i==17)
			{setupBlanklist(UnitsList);
			setFieldText(UnitsField, "torr/s");
			setFieldText(ConstantField2, "L");
			setFieldText(ConstValueField, "1e-6");
			d=17;}
			if(i==18)
			{setupBlanklist(UnitsList);
			setFieldText(UnitsField, "C/mol");
			setFieldText(ConstantField2, "F");
			setFieldText(ConstValueField, "96485.3415");
			d=18;}
			if(i==19)
			{setupBlanklist(UnitsList);
			setFieldText(UnitsField, " ");
			setFieldText(ConstantField2, "alpha");
			setFieldText(ConstValueField, "7.297352533e-3");
			d=19;}
			if(i==20)
			{setupBlanklist(UnitsList);
			setFieldText(UnitsField, " ");
			setFieldText(ConstantField2, "alpha^-1");
			setFieldText(ConstValueField, "137.03599976");
			d=20;}
			if(i==21)
			{setupListHartreeUnits2(UnitsList);
			d=21;}
			if(i==22)
			{setupListJouleUnits2(UnitsList);
			d=22;}
			if(i==23)
			{setupListKelvinUnits2(UnitsList);
			d=23;}
			if(i==24)
			{setupListkgUnits2(UnitsList);
			d=24;}
			if(i==25)
			{setupBlanklist(UnitsList);
			setFieldText(UnitsField, "m");
			setFieldText(ConstantField2, "a");
			setFieldText(ConstValueField, "0.543102088e-9");
			d=25;}
			if(i==26)
			{setupBlanklist(UnitsList);
			setFieldText(UnitsField, "N/A�");
			setFieldText(ConstantField2, "mu0 = 4PI*1e-7");
			setFieldText(ConstValueField, "12.566370614e-7");
			d=26;}
			if(i==27)
			{setupBlanklist(UnitsList);
			setFieldText(UnitsField, "Wb");
			setFieldText(ConstantField2, "Phi0");
			setFieldText(ConstValueField, "2.067833636e-15");
			d=27;}
			if(i==28)
			{setupBlanklist(UnitsList);
			setFieldText(UnitsField, "m^3/(kg*s�)");
			setFieldText(ConstantField2, "G");
			setFieldText(ConstValueField, "6.673e-11");
			d=28;}
			if(i==29)
			{setupBlanklist(UnitsList);
			setFieldText(UnitsField, "1/(GeV/c�)�");
			setFieldText(ConstantField2, "G/(hbar*c)");
			setFieldText(ConstValueField, "6.707e-39");
			d=29;}
			if(i==30)
			{setupListPlanckUnits(UnitsList);
			d=30;}
			if(i==31)
			{setupListPlanckUnits(UnitsList);	
			d=31;}
			if(i==32)
			{setupListRydbergUnits(UnitsList);
			d=32;}
			if(i==33)
			{setupBlanklist(UnitsList);
			setFieldText(UnitsField, "m/s");
			setFieldText(ConstantField2, "c, c0");
			setFieldText(ConstValueField, "299792458");
			d=33;}
			if(i==34)
			{setupBlanklist(UnitsList);
			setFieldText(UnitsField, "m/s�");
			setFieldText(ConstantField2, "g");
			setFieldText(ConstValueField, "9.80665");
			d=34;}
			if(i==35)
			{setupBlanklist(UnitsList);
			setFieldText(UnitsField, "Pa");
			setFieldText(ConstantField2, " ");
			setFieldText(ConstValueField, "101325");
			d=35;}
			if(i==36)
			{setupBlanklist(UnitsList);
			setFieldText(UnitsField, "W/(m*K�)�");
			setFieldText(ConstantField2, "sigma");
			setFieldText(ConstValueField, "5.670400e-8");
			d=36;}

			handled = true;
			break;
		
	case UnitsPopup:
			if(d==0)
			{setFieldText(UnitsField, listAstroUnits2[i]);
			setFieldText(ConstantField2, listAstroUnits[i]);
			setFieldText(ConstValueField, listAstroValues1[i]);
			}

			if(d==1)
			{setFieldText(UnitsField, listAtomicMassUnits[i]);
			setFieldText(ConstantField2, listAtomicMassUnits2[i]);
			setFieldText(ConstValueField, listAtomicMassValues1[i]);
			}
			if(d==2)
			{setFieldText(UnitsField, listAtomicUnits[i]);
			setFieldText(ConstantField2, listAtomicUnits2[i]);
			setFieldText(ConstValueField, listAtomicValues1[i]);
			}
			if(d==4)
			{setFieldText(UnitsField, listBohrMagUnits[i]);
			setFieldText(ConstantField2, listBohrMagUnits2[i]);
			setFieldText(ConstValueField, listBohrMagValues1[i]);
			}

			if(d==6)
			{setFieldText(UnitsField, listBoltzmannUnits[i]);
			setFieldText(ConstantField2, listBoltzmannUnits2[i]);
			setFieldText(ConstValueField, listBoltzmannValues1[i]);
			}
			if(d==13)
			{setFieldText(UnitsField, listElMagMomUnits[i]);
			setFieldText(ConstantField2, listElMagMomUnits2[i]);
			setFieldText(ConstValueField, listElMagMomValues1[i]);}
			if(d==14)
			{setFieldText(UnitsField, listElMassUnits[i]);
			setFieldText(ConstantField2, listElMassUnits2[i]);
			setFieldText(ConstValueField, listElMassValues1[i]);}
			if(d==15)
			{setFieldText(UnitsField, listElVoltUnits[i]);
			setFieldText(ConstantField2, listElVoltUnits2[i]);
			setFieldText(ConstValueField, listElVoltValues1[i]);}

			if(d==21)
			{setFieldText(UnitsField, listHartreeUnits[i]);
			setFieldText(ConstantField2, listHartreeUnits2[i]);
			setFieldText(ConstValueField, listHartreeValues1[i]);}
			if(d==22)
			{setFieldText(UnitsField, listJouleUnits[i]);
			setFieldText(ConstantField2, listJouleUnits2[i]);
			setFieldText(ConstValueField, listJouleValues1[i]);}
			if(d==23)
			{setFieldText(UnitsField, listKelvinUnits[i]);
			setFieldText(ConstantField2, listKelvinUnits2[i]);
			setFieldText(ConstValueField, listKelvinValues1[i]);}
			if(d==24)
			{setFieldText(UnitsField, listkgUnits[i]);
			setFieldText(ConstantField2, listkgUnits2[i]);
			setFieldText(ConstValueField, listkgValues1[i]);}			
			if(d==30)
			{setFieldText(UnitsField, listPlanckUnits[i]);
			setFieldText(ConstantField2, listPlanckUnits2[i]);
			setFieldText(ConstValueField, listPlanckValues1[i]);}
			if(d==31)
			{setFieldText(UnitsField, listPlanckUnits[i]);
			setFieldText(ConstantField2, listPlanckUnits2[i]);
			setFieldText(ConstValueField, listPlanckValues2[i]);}
			if(d==32)
			{setFieldText(UnitsField, listRydbergUnits[i]);
			setFieldText(ConstantField2, listRydbergUnits2[i]);
			setFieldText(ConstValueField, listRydbergValues1[i]);}



			handled = true;
			break;
		}
		}
		}
		return handled;
	}


static Boolean
	AboutFormEventHandler(EventPtr event)
	{
		Boolean	handled	= false;
		FormPtr	frmP	= FrmGetActiveForm();
		switch (event->eType) 
		{

		/*
		 * the first event received by a form's event handler is
		 * the frmOpenEvent.  
		 */

		case frmOpenEvent:
			FrmDrawForm(frmP);
			AboutFormInit(frmP);
			handled = true;
			break;  
		
		
		// *** ADD EVENT HANDLING HERE *** //
//BUTTONS
		case ctlSelectEvent:
			switch(event->data.ctlSelect.controlID)
			{
			case	CloseAboutMenuBtn:
			{	if(g==0)
				{FrmGotoForm(MainForm);}
				if(g==1)
				{FrmGotoForm(SIForm);}
				handled = true;
				break;
			}
			//other buttons...
			}
			break;
}
return handled;
}

		
static Boolean
	SIFormEventHandler(EventPtr event)
	{
		Boolean	handled	= false;
		FormPtr	frmP	= FrmGetActiveForm();
		switch (event->eType) 
		{

		/*
		 * the first event received by a form's event handler is
		 * the frmOpenEvent.  
		 */

		case frmOpenEvent:
			FrmDrawForm(frmP);
			SIFormInit(frmP);
			handled = true;
			break;  
		case menuEvent:
			handled=doMenuSI(frmP, event->data.menu.itemID);
			break;

		
		// *** ADD EVENT HANDLING HERE *** //
//BUTTONS
		case ctlSelectEvent:
			switch(event->data.ctlSelect.controlID)
			{
			case	ConstBtn:
			{	FrmGotoForm(MainForm);
				handled = true;
				break;
			}
			//other buttons...
			}
			break;
//LIST

case popSelectEvent:
	{
		int	i	= event->data.popSelect.selection;

		switch (event->data.popSelect.controlID)
		{
		case SIPopup:
			{			
			setFieldText(QuantityField, listSIQuantity[i]);
			setFieldText(NameSIField, listSIName[i]);
			setFieldText(SymbolSIField, listSISymbol[i]);
			setFieldText(SymbolDerField, " ");

	
			handled = true;
				break;
			}
		case DerPopup:
			{			
			setFieldText(QuantityField, listDerQuantity[i]);
			setFieldText(NameSIField, listDerName[i]);
			setFieldText(SymbolSIField, listDerSymbol[i]);
			setFieldText(SymbolDerField, listDerUnits[i]);
			setFieldText(SymbolDerInfo, listDerInfo[i]);
			

	
				handled = true;
				break;
			}
			
		
}
}
}
return handled;
}

	

	/*
	 * This is the startup code for the form.  Here, we write our message 
	 * to the screen.
	 */

		static void 
	mainFormInit (FormPtr frmP)
	{g=0;
	setupListM(ConstantList);
	
	setFieldText(ConstValueField, " ");
		
		// *** ADD FORM INITIALIZATION HERE *** //
		
	}


	static void 
	AboutFormInit (FormPtr frmP)
	{//setupListM(ConstantList);
	
	//setFieldText(ConstValueField, " ");
		
		// *** ADD FORM INITIALIZATION HERE *** //
		
	}

static void 
	SIFormInit (FormPtr frmP)
	{	g=1;
		setupListSIQuantity(SIList);
		setupListDerQuantity(DerList);
	//setFieldText(ConstValueField, " ");
		
		// *** ADD FORM INITIALIZATION HERE *** //
		
	}




static Boolean	doMenu(FormPtr frmP, Word command)
{
	Boolean handled = false;
	switch (command) {
		case OptionsMenuAbout:
			FrmGotoForm(AboutForm);
			handled = true;
			break;
		case CopyMenu:
			getFieldText(ConstValueField, StringCopy);
			ClipboardAddItem (clipboardText, StringCopy,StrLen(StringCopy));
			handled = true;
			break;
		case ConstMenu:
			FrmGotoForm(SIForm);
			handled = true;
			break;

	}
	return handled;
}

static Boolean	doMenuSI(FormPtr frmP, Word command)
{
	Boolean handled = false;
	switch (command) {
		case OptionsMenuAbout:
			FrmGotoForm(AboutForm);
			handled = true;
			break;
		case SIMenu:
			FrmGotoForm(MainForm);
			handled = true;
			break;
	}
	return handled;
}



void	*
	getObjectPtr (FormPtr frmP, Int resourceNo)
	{
		UInt16 objIndex=FrmGetObjectIndex(frmP,resourceNo);
		return FrmGetObjectPtr(frmP,objIndex);
	}

static void 
	setFieldText	(UInt32	fIndex, 
			 char	*StrToShow)
	{
		FormPtr frmP	= FrmGetActiveForm();
		void	*fieldP = getObjectPtr (frmP, fIndex);

		// get the field's old text handle
		Handle	oldH	= FldGetTextHandle(fieldP);
		
		//Copy our string into a memhandle

		int	len	= StrLen(StrToShow);
		Handle	mH	= MemHandleNew(len+1);
		char	*mP	= MemHandleLock(mH);

		StrCopy(mP, StrToShow);
		
		//The memhandle needs to be unlocked to work...
		MemHandleUnlock(mH);

		//To establish the field's link to the handle
		FldSetTextHandle(fieldP,mH);

		//To draw the field
		FldDrawField(fieldP);
		
		// get rid of old handle
		if (oldH != NULL)
			MemHandleFree (oldH);
	}

// Use a function like this to find out what the field's contents 
	// are and to put them into a string:

		static void 
	getFieldText (UInt32 fIndex, char *StrToGet)
	{
		FormPtr	frmP = FrmGetActiveForm();
		void	*fieldP = getObjectPtr (frmP, fIndex);

		Handle mH = FldGetTextHandle(fieldP);
		char *mP=MemHandleLock(mH);
		StrCopy(StrToGet, mP);
		
		MemHandleUnlock(mH);
	}



