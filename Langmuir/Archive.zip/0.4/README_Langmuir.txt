Langmuir for PalmOS
---------------------

Requirements

1) PalmOS powered PDA. This program has been tested on PalmOS 3.5, 4.1, 5, 5.2
2) MathLib.prc library



Legal statement

This program is freeware. It can be distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. It can not be altered or modified in any way without the permission of the author. Separate distribution of the following 2 files:

Langmuir.prc
README_Langmuir.txt (this file)

is not permitted. However the distribution of the the overall package is warmly encouraged.




For comments, suggestions, bugs, please email me:

Nicola Ferralis
feranick@hotmail.com

 
(version included in this distribution: 0.4 built 092203)
