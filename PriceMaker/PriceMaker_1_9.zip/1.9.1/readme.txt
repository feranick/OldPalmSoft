PriceMaker 1.9 (Pre-release 2.0) - (12/08/05)
----------------------------------------------

This is a pre-release version. Although it has been tested, you may find bugs. 
I would appreciate if you could report them to me.
The results from the calculations are not completely tested. 
I strongly advise to use the stable version 1.3 for any use other than testing
You may find the latest release version (1.3) here:

http://geocities.com/leedhas/

Thank you for choosing PriceMaker.

Nicola Ferralis
feranick@hotmail.com