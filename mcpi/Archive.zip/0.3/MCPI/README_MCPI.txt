MCPI for PalmOS
---------------------

Requirements

1) PalmOS powered PDA. This program has been tested on PalmOS 3.5, 4.1, 5, 5.2
2) MathLib.prc library


Warning:

1) If you run more than 10000 cycles, the simulation can take a long time. This may deplete the batteries of your PDA. Use with caution.
2) The final value of PI may be significantly different from the tabulated (PI=3.14159). This is due mainly to the random number generator, which is indeed not perfectly random. For this reason, use this program only for demo purpose, benchmark, or educational use. WE ARE NOT RESPONSIBLE FOR ANY DATA LOSS. 


Legal statement:

This program is freeware. It can be distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. It can not be altered or modified in any way without the permission of the author. Separate distribution of the following 2 files:

MCPI.prc
README_MCPI.txt (this file)

is not permitted. However the distribution of the the overall package is warmly encouraged.




For comments, suggestions, bugs, please email me:

Nicola Ferralis
feranick@hotmail.com

 
(version included in this distribution: 0.3.1 built 052503)
